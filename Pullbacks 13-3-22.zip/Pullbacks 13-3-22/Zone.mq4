#property copyright "Copyright � 2015, LEXUNO"
#property link      "profitized2014@yahoo.com"

#property indicator_chart_window

extern string _ = "������ ���. ��� (1-M1, 5-M5, 15-M15, 30-M30, 60-�1, 240-�4, 1440-D1, 10080-W1, 43200-MN1)";
extern int TF = 60;
extern string __ = "���-�� ����� � ��� ����������� ���";
extern int MaxBars = 1000;
extern color Rcolor = Red;
extern color Scolor = LimeGreen;
extern color TxtColor = DarkGray;
extern bool BackGround = FALSE;
extern int RectangleWidth = 2;
extern int RectangleStyle = 0;
extern int TxtSize = 8;
extern string ___ = "����� ���� ����� �� RectShift �����";
extern int RectShift = 10;
extern string ____ = "��������� ����������� ��";
extern int MA1 = 1;
extern int MA2 = 5;
extern int Metod_MA = 1;
extern int Price_MA = 0;
int Gi_164 = 4;
int Gi_168;
int Gi_172;
int G_bars_176;
int G_bars_180;
string Gs_184;
bool Gi_192;
int Gia_196[];
int Gia_200[];
double Gda_204[];
double Gda_208[];
string Gsa_212[];

// E37F0136AA3FFAF149B351F6A4C948E9
int init() {
   switch (TF) {
   case 1:
      Gs_184 = "M1";
      break;
   case 5:
      Gs_184 = "M5";
      break;
   case 15:
      Gs_184 = "M15";
      break;
   case 30:
      Gs_184 = "M30";
      break;
   case 60:
      Gs_184 = "H1";
      break;
   case 240:
      Gs_184 = "H4";
      break;
   case 1440:
      Gs_184 = "D1";
      break;
   case 10080:
      Gs_184 = "W1";
      break;
   case 43200:
      Gs_184 = "MN1";
      break;
   default:
      Alert(" ������ �� ������������ ����������! ���������� ������ �1");
      TF = 60;
      Gs_184 = "H1";
   }
   Gi_192 = TRUE;
   return (0);
}

// 52D46093050F38C27267BCE42543EF60
void deinit() {
   for (int count_0 = 0; count_0 < MaxBars / 3; count_0++) {
      ObjectDelete("R" + Gs_184 + count_0);
      ObjectDelete("R" + Gs_184 + "t" + count_0);
      ObjectDelete("R" + Gs_184 + "l" + count_0);
      ObjectDelete("S" + Gs_184 + count_0);
      ObjectDelete("S" + Gs_184 + "t" + count_0);
      ObjectDelete("S" + Gs_184 + "l" + count_0);
   }
}

// 945D754CB0DC06D04243FCBA25FC0802
int f0_3(int Ai_0) {
   double Ld_4 = iMA(NULL, TF, MA1, 0, Metod_MA, Price_MA, Ai_0) - iMA(NULL, TF, MA2, 0, Metod_MA, Price_MA, Ai_0);
   if (Ld_4 > Point / 2.0) return (1);
   if (Ld_4 < (-Point) / 2.0) return (-1);
   return (0);
}

// 2569208C5E61CB15E209FFE323DB48B7
int f0_1(int Ai_0) {
   if (Ai_0 < iBars(Symbol(), TF) - 3) {
      if (iHigh(NULL, TF, Ai_0 + 2) < iHigh(NULL, TF, Ai_0 + 1) && iHigh(NULL, TF, Ai_0 + 1) < iHigh(NULL, TF, Ai_0)) return (1);
      return (0);
   }
   return (0);
}

// 6ABA3523C7A75AAEA41CC0DEC7953CC5
int f0_2(int Ai_0) {
   if (Ai_0 < iBars(Symbol(), TF) - 2) {
      if (!(!iLow(NULL, TF, Ai_0 + 2) > iLow(NULL, TF, Ai_0 + 1) && iLow(NULL, TF, Ai_0 + 1) > iLow(NULL, TF, Ai_0))) return (1);
      return (0);
   }
   return (0);
}

// 09CBB5F5CE12C31A043D5C81BF20AA4A
int f0_0(int Ai_0) {
   if (iLow(NULL, TF, Ai_0) == iLow(NULL, TF, Ai_0 - 1)) Ai_0--;
   if (Ai_0 > 3) {
      if (!(!(iHigh(NULL, TF, Ai_0) < iHigh(NULL, TF, Ai_0 - 1) && iHigh(NULL, TF, Ai_0 - 1) < iHigh(NULL, TF, Ai_0 - 2)) || (iHigh(NULL, TF, Ai_0 - 1) < iHigh(NULL, TF,
         Ai_0 - 2) && iHigh(NULL, TF, Ai_0 - 2) < iHigh(NULL, TF, Ai_0 - 3)))) return (1);
      return (0);
   }
   return (0);
}

// 9B1AEE847CFB597942D106A4135D4FE6
int f0_4(int Ai_0) {
   if (iHigh(NULL, TF, Ai_0) == iHigh(NULL, TF, Ai_0 - 1)) Ai_0--;
   if (Ai_0 > 3) {
      if (!(!(iLow(NULL, TF, Ai_0) > iLow(NULL, TF, Ai_0 - 1) && iLow(NULL, TF, Ai_0 - 1) > iLow(NULL, TF, Ai_0 - 2)) || (iLow(NULL, TF, Ai_0 - 1) > iLow(NULL, TF, Ai_0 - 2) &&
         iLow(NULL, TF, Ai_0 - 2) > iLow(NULL, TF, Ai_0 - 3)))) return (1);
      return (0);
   }
   return (0);
}

// EA2B2676C28C0DB26D39331A336C6B92
int start() {
   int index_0;
   bool Li_4;
   int highest_8;
   int highest_12;
   int Li_16;
   int Li_20;
   int highest_24;
   int highest_28;
   double Ld_32;
   double Ld_40;
   double ihigh_48;
   double ilow_56;
   double Ld_64;
   bool bool_72;
   bool bool_76;
   bool Li_80;
   bool Li_84;
   G_bars_176 = Bars;
   Gi_168 = iBars(Symbol(), TF);
   if (Gi_172 != Gi_168 || Gi_192) {
      Gi_192 = FALSE;
      Gi_172 = Gi_168;
      ArrayResize(Gia_196, 0);
      ArrayResize(Gia_200, 0);
      ArrayResize(Gda_204, 0);
      ArrayResize(Gda_208, 0);
      ArrayResize(Gsa_212, 0);
      index_0 = 0;
      if (MaxBars > Gi_168) MaxBars = Gi_168;
      for (int Li_88 = f0_3(MaxBars); Li_88 == 0; Li_88 = f0_3(MaxBars)) MaxBars--;
      Li_16 = MaxBars;
      for (int Li_92 = MaxBars; Li_92 > 2; Li_92--) {
         Li_80 = FALSE;
         Li_84 = FALSE;
         Li_20 = f0_3(Li_92);
         bool_72 = f0_1(Li_92) && f0_4(Li_92);
         bool_76 = f0_2(Li_92) && f0_0(Li_92);
         if (bool_72) {
            highest_24 = iHighest(NULL, TF, MODE_OPEN, 6, Li_92 - 3);
            Ld_32 = iOpen(NULL, TF, highest_24);
            highest_28 = iHighest(NULL, TF, MODE_CLOSE, 6, Li_92 - 3);
            Ld_40 = iClose(NULL, TF, highest_28);
            if (Ld_40 > Ld_32) highest_8 = highest_28;
            else highest_8 = highest_24;
            highest_8 = iHighest(NULL, TF, MODE_HIGH, 3, highest_8 - 1);
            ihigh_48 = iHigh(NULL, TF, highest_8);
            Li_80 = TRUE;
         } else {
            if (Li_20 != Li_88 && Li_20 != 0 && Li_88 > 0) {
               if (Li_16 - Li_92 > 1) {
                  highest_24 = iHighest(NULL, TF, MODE_OPEN, Li_16 - Li_92, Li_92);
                  Ld_32 = iOpen(NULL, TF, highest_24);
                  highest_28 = iHighest(NULL, TF, MODE_CLOSE, Li_16 - Li_92, Li_92);
                  Ld_40 = iClose(NULL, TF, highest_28);
                  if (Ld_40 > Ld_32) highest_8 = highest_28;
                  else highest_8 = highest_24;
                  highest_8 = iHighest(NULL, TF, MODE_HIGH, 3, highest_8 - 1);
                  ihigh_48 = iHigh(NULL, TF, highest_8);
                  if (f0_1(highest_8) || f0_4(highest_8) || Li_16 - Li_92 > Gi_164) Li_80 = TRUE;
               }
               Li_88 = Li_20;
               Li_16 = Li_92;
            }
         }
         if (bool_76) {
            highest_24 = iLowest(NULL, TF, MODE_OPEN, 6, Li_92 - 3);
            Ld_32 = iOpen(NULL, TF, highest_24);
            highest_28 = iLowest(NULL, TF, MODE_CLOSE, 6, Li_92 - 3);
            Ld_40 = iClose(NULL, TF, highest_28);
            if (Ld_40 < Ld_32) highest_12 = highest_28;
            else highest_12 = highest_24;
            ilow_56 = iLow(NULL, TF, highest_12);
            Li_84 = TRUE;
         } else {
            if (Li_20 != Li_88 && Li_20 != 0 && Li_88 < 0) {
               if (Li_16 - Li_92 > 1) {
                  highest_24 = iLowest(NULL, TF, MODE_OPEN, Li_16 - Li_92, Li_92);
                  Ld_32 = iOpen(NULL, TF, highest_24);
                  highest_28 = iLowest(NULL, TF, MODE_CLOSE, Li_16 - Li_92, Li_92);
                  Ld_40 = iClose(NULL, TF, highest_28);
                  if (Ld_40 < Ld_32) highest_12 = highest_28;
                  else highest_12 = highest_24;
                  highest_12 = iLowest(NULL, TF, MODE_LOW, 3, highest_12 - 1);
                  ilow_56 = iLow(NULL, TF, highest_12);
                  if (f0_2(highest_12) || f0_0(highest_12) || Li_16 - Li_92 > Gi_164) Li_84 = TRUE;
               }
               Li_88 = Li_20;
               Li_16 = Li_92;
            }
         }
         if (Li_80) {
            Ld_32 = iOpen(NULL, TF, iHighest(NULL, TF, MODE_OPEN, highest_8 + 1));
            Ld_40 = iClose(NULL, TF, iHighest(NULL, TF, MODE_CLOSE, highest_8 + 1));
            if (Ld_40 > Ld_32) Ld_64 = Ld_40;
            else Ld_64 = Ld_32;
            Li_4 = FALSE;
            if (Ld_64 <= ihigh_48) {
               for (int Li_96 = index_0; Li_96 >= 0; Li_96--) {
                  if (Gsa_212[Li_96] == "R" && Gia_200[Li_96] > iTime(NULL, TF, Li_92)) {
                     if (ihigh_48 <= Gda_204[Li_96] && Ld_64 >= Gda_208[Li_96]) {
                        Li_4 = TRUE;
                        continue;
                     }
                     if (ihigh_48 > Gda_204[Li_96]) {
                        Gia_200[Li_96] = iTime(NULL, TF, highest_8);
                        continue;
                     }
                     if (Ld_64 <= Gda_208[Li_96] && ihigh_48 >= Gda_208[Li_96] && ihigh_48 <= Gda_204[Li_96]) {
                        Gia_200[Li_96] = iTime(NULL, TF, highest_8);
                        ihigh_48 = Gda_204[Li_96];
                     }
                  }
               }
            }
            if (Ld_64 <= ihigh_48 && Li_4 == FALSE) {
               ArrayResize(Gia_196, index_0 + 1);
               ArrayResize(Gia_200, index_0 + 1);
               ArrayResize(Gda_204, index_0 + 1);
               ArrayResize(Gda_208, index_0 + 1);
               ArrayResize(Gsa_212, index_0 + 1);
               Gia_196[index_0] = iTime(NULL, TF, highest_8);
               Gia_200[index_0] = iTime(NULL, 0, 0) + 60 * RectShift * Period();
               Gda_204[index_0] = ihigh_48;
               Gda_208[index_0] = Ld_64;
               Gsa_212[index_0] = "R";
               index_0++;
            }
            Li_80 = FALSE;
         }
         if (Li_84) {
            Ld_32 = iOpen(NULL, TF, iLowest(NULL, TF, MODE_OPEN, highest_12 + 1));
            Ld_40 = iClose(NULL, TF, iLowest(NULL, TF, MODE_CLOSE, highest_12 + 1));
            if (Ld_40 < Ld_32) Ld_64 = Ld_40;
            else Ld_64 = Ld_32;
            Li_4 = FALSE;
            if (Ld_64 >= ilow_56) {
               for (Li_96 = index_0; Li_96 >= 0; Li_96--) {
                  if (Gsa_212[Li_96] == "S" && Gia_200[Li_96] > iTime(NULL, TF, Li_92)) {
                     if (ilow_56 >= Gda_204[Li_96] && Ld_64 <= Gda_208[Li_96]) {
                        Li_4 = TRUE;
                        continue;
                     }
                     if (ilow_56 < Gda_204[Li_96]) {
                        Gia_200[Li_96] = iTime(NULL, TF, highest_12);
                        continue;
                     }
                     if (Ld_64 >= Gda_208[Li_96] && ilow_56 <= Gda_208[Li_96] && ilow_56 >= Gda_204[Li_96]) {
                        Gia_200[Li_96] = iTime(NULL, TF, highest_12);
                        ilow_56 = Gda_204[Li_96];
                     }
                  }
               }
            }
            if (Ld_64 >= ilow_56 && Li_4 == FALSE) {
               ArrayResize(Gia_196, index_0 + 1);
               ArrayResize(Gia_200, index_0 + 1);
               ArrayResize(Gda_204, index_0 + 1);
               ArrayResize(Gda_208, index_0 + 1);
               ArrayResize(Gsa_212, index_0 + 1);
               Gia_196[index_0] = iTime(NULL, TF, highest_12);
               Gia_200[index_0] = iTime(NULL, 0, 0) + 60 * RectShift * Period();
               Gda_204[index_0] = ilow_56;
               Gda_208[index_0] = Ld_64;
               Gsa_212[index_0] = "S";
               index_0++;
            }
            Li_84 = FALSE;
         }
      }
   }
   if (G_bars_180 != G_bars_176) {
      G_bars_180 = G_bars_176;
      for (Li_92 = 0; Li_92 < MaxBars / 3; Li_92++) {
         ObjectDelete("R" + Gs_184 + Li_92);
         ObjectDelete("R" + Gs_184 + "t" + Li_92);
         ObjectDelete("R" + Gs_184 + "l" + Li_92);
         ObjectDelete("S" + Gs_184 + Li_92);
         ObjectDelete("S" + Gs_184 + "t" + Li_92);
         ObjectDelete("S" + Gs_184 + "l" + Li_92);
      }
      for (Li_92 = 0; Li_92 < ArraySize(Gia_196); Li_92++) {
         if (iBarShift(NULL, TF, Gia_200[Li_92]) <= 0) Gia_200[Li_92] = iTime(NULL, 0, 0) + 60 * RectShift * Period();
         if (Gsa_212[Li_92] == "R") {
            ObjectCreate("R" + Gs_184 + Li_92, OBJ_RECTANGLE, 0, Gia_196[Li_92], Gda_204[Li_92], Gia_200[Li_92], Gda_208[Li_92]);
            ObjectSet("R" + Gs_184 + Li_92, OBJPROP_COLOR, Rcolor);
            ObjectSet("R" + Gs_184 + Li_92, OBJPROP_BACK, BackGround);
            ObjectSet("R" + Gs_184 + Li_92, OBJPROP_WIDTH, RectangleWidth);
            ObjectSet("R" + Gs_184 + Li_92, OBJPROP_STYLE, RectangleStyle);
            if (Gda_204[Li_92] == Gda_208[Li_92]) ObjectSet("R" + Gs_184 + Li_92, OBJPROP_BACK, FALSE);
            if (iBarShift(NULL, TF, Gia_200[Li_92]) <= 0) {
               ObjectCreate("R" + Gs_184 + "l" + Li_92, OBJ_TREND, 0, Gia_196[Li_92], Gda_208[Li_92], Gia_200[Li_92], Gda_208[Li_92]);
               ObjectSet("R" + Gs_184 + "l" + Li_92, OBJPROP_COLOR, TxtColor);
               ObjectSet("R" + Gs_184 + "l" + Li_92, OBJPROP_STYLE, STYLE_DOT);
               ObjectCreate("R" + Gs_184 + "t" + Li_92, OBJ_TEXT, 0, Gia_200[Li_92], Gda_208[Li_92] + TxtSize / 4 * Point);
               ObjectSetText("R" + Gs_184 + "t" + Li_92, "R" + Gs_184, TxtSize, "Arial", TxtColor);
            }
         } else {
            if (Gsa_212[Li_92] == "S") {
               ObjectCreate("S" + Gs_184 + Li_92, OBJ_RECTANGLE, 0, Gia_196[Li_92], Gda_204[Li_92], Gia_200[Li_92], Gda_208[Li_92]);
               ObjectSet("S" + Gs_184 + Li_92, OBJPROP_COLOR, Scolor);
               ObjectSet("S" + Gs_184 + Li_92, OBJPROP_BACK, BackGround);
               ObjectSet("S" + Gs_184 + Li_92, OBJPROP_WIDTH, RectangleWidth);
               ObjectSet("S" + Gs_184 + Li_92, OBJPROP_STYLE, RectangleStyle);
               if (Gda_204[Li_92] == Gda_208[Li_92]) ObjectSet("S" + Gs_184 + Li_92, OBJPROP_BACK, FALSE);
               if (iBarShift(NULL, TF, Gia_200[Li_92]) <= 0) {
                  ObjectCreate("S" + Gs_184 + "l" + Li_92, OBJ_TREND, 0, Gia_196[Li_92], Gda_208[Li_92], Gia_200[Li_92], Gda_208[Li_92]);
                  ObjectSet("S" + Gs_184 + "l" + Li_92, OBJPROP_COLOR, TxtColor);
                  ObjectSet("S" + Gs_184 + "l" + Li_92, OBJPROP_STYLE, STYLE_DOT);
                  ObjectCreate("S" + Gs_184 + "t" + Li_92, OBJ_TEXT, 0, Gia_200[Li_92], Gda_208[Li_92]);
                  ObjectSetText("S" + Gs_184 + "t" + Li_92, "S" + Gs_184, TxtSize, "Arial", TxtColor);
               }
            }
         }
      }
   }
   return (0);
}
